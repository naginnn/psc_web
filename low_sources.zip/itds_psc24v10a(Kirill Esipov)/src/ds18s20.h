/*----------------------------------------------------------------------------
	������:		ITDS PSC UPS 24
	����:		ds18s29.h
	��������:	15:30 31.07.2011
	��������:	��� "��� �-�������"
	�����:		�.�.�.
----------------------------------------------------------------------------*/


#ifndef DS18S20_MODULE
#define DS18S20_MODULE

#define POLLING_TIME    1000

#define ONE_WIRE_DO PORTDbits.RD2
#define ONE_WIRE_DI PORTDbits.RD3


struct Bus1wireStruct {
	/*
	0x01 - Convert T
	0x10 - Read Scratchpad Sensor[Sensor_N-1]

	0x20 - Read ROM To Sensor {SensorRS232_N-1]
	*/
	unsigned char Task;

	unsigned char State;
	unsigned char Sensor_N;
	unsigned int c_Start;

	unsigned char BufTemp;

	unsigned char BufRx[9];
	unsigned char BufTx;
	unsigned char c_Bit;
	unsigned char c_Byte;
    unsigned char c_Error;
    unsigned char c_ErrorResponsPulse;
	unsigned char SRPhase;
	unsigned char BufBit;

	unsigned char SensorRS232_N;
};

struct TSensorStruct {
	unsigned char Id[8];
	unsigned char ScrathPad[9];

	unsigned char c_ErrorCRC8;

	unsigned char Flag;
	float T_Value;
};

void InitTimer4(void);
unsigned char CRC8_Calculate(unsigned char *pcBlock, unsigned int len);

#endif

