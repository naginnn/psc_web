/*----------------------------------------------------------------------------
	������:		ITDS PSC UPS 24
	����:		uart.h
	��������:	14:44 08.07.2011
	��������:	��� "��� �-�������"
	�����:		�.�.�.
----------------------------------------------------------------------------*/


#ifndef UART_MODULE
#define UART_MODULE


#define B2400 520
#define B4800 259
#define B9600 129
#define B19200 64
#define B38400 32
#define B57600 21
#define B115200 10

#define UTxRx PORTFbits.RF6

#define RXSIZE	261
#define TXSIZE	261

#define LEDTXTICK 20

struct UARTdataStruct{
	unsigned int BaudRate;
	unsigned char Parity;

	unsigned char BufTemp;
	unsigned int BufRxCounter;
	unsigned int BufTxCounter;
	unsigned int BufTxMessLen;
	unsigned char NetAddress;
	unsigned char LEDCntTx;
	unsigned char LEDCntRx;
	unsigned int Timer;
	struct {
		unsigned char isTx;
		unsigned char isRx;
		unsigned char IEC101;
		unsigned char ModBus;
		unsigned char START_RX;
		unsigned char START_TX;
		unsigned char FERR;
		unsigned char PERR;
	} Status;
	unsigned char BufRx[RXSIZE];
	unsigned char BufTx[TXSIZE];
};


void InitUART1(void);
void EnableUART1(void);
void DisableUART1(void);
void InitUART2(void);
void EnableUART2(void);
void DisableUART2(void);



#endif

