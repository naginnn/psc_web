/*----------------------------------------------------------------------------
	������:		ITDS PSC UPS 24
	����:		modbus.c
	��������:	10:15 10.06.2011
	��������:	��� "��� �-�������"
	�����:		�.�.�.
----------------------------------------------------------------------------*/

#include "share_data.h"


//-------------���������� ����������---------------------------------------------
unsigned short CRC16;
unsigned char ErrorCode;


//-------------������ ModBusCRC16 (polynom: 0xA001)------------------------------
const unsigned char TabCRCHi[] =
{
0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81,
0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01,
0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81,
0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01,
0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81,
0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01,
0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81,
0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01,
0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81,
0x40
};
const unsigned char TabCRCLo[] =
{
0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06, 0x07, 0xC7, 0x05, 0xC5, 0xC4,
0x04, 0xCC, 0x0C, 0x0D, 0xCD, 0x0F, 0xCF, 0xCE, 0x0E, 0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09,
0x08, 0xC8, 0xD8, 0x18, 0x19, 0xD9, 0x1B, 0xDB, 0xDA, 0x1A, 0x1E, 0xDE, 0xDF, 0x1F, 0xDD,
0x1D, 0x1C, 0xDC, 0x14, 0xD4, 0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3,
0x11, 0xD1, 0xD0, 0x10, 0xF0, 0x30, 0x31, 0xF1, 0x33, 0xF3, 0xF2, 0x32, 0x36, 0xF6, 0xF7,
0x37, 0xF5, 0x35, 0x34, 0xF4, 0x3C, 0xFC, 0xFD, 0x3D, 0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A,
0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38, 0x28, 0xE8, 0xE9, 0x29, 0xEB, 0x2B, 0x2A, 0xEA, 0xEE,
0x2E, 0x2F, 0xEF, 0x2D, 0xED, 0xEC, 0x2C, 0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26,
0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0, 0xA0, 0x60, 0x61, 0xA1, 0x63, 0xA3, 0xA2,
0x62, 0x66, 0xA6, 0xA7, 0x67, 0xA5, 0x65, 0x64, 0xA4, 0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F,
0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB, 0x69, 0xA9, 0xA8, 0x68, 0x78, 0xB8, 0xB9, 0x79, 0xBB,
0x7B, 0x7A, 0xBA, 0xBE, 0x7E, 0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 0xB4, 0x74, 0x75, 0xB5,
0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71, 0x70, 0xB0, 0x50, 0x90, 0x91,
0x51, 0x93, 0x53, 0x52, 0x92, 0x96, 0x56, 0x57, 0x97, 0x55, 0x95, 0x94, 0x54, 0x9C, 0x5C,
0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E, 0x5A, 0x9A, 0x9B, 0x5B, 0x99, 0x59, 0x58, 0x98, 0x88,
0x48, 0x49, 0x89, 0x4B, 0x8B, 0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C,
0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42, 0x43, 0x83, 0x41, 0x81, 0x80,
0x40
};

unsigned short CalculateCRC16(unsigned char *PBuffer, unsigned int DataLen)
{
	unsigned char CRCHi = 0xFF ; //DynamicData
	unsigned char CRCLo = 0xFF ;
	unsigned int  Index = 0;
	while (DataLen--)
	{
		Index = CRCLo ^ *PBuffer++ ;
		CRCLo = CRCHi ^ TabCRCHi[Index];
		CRCHi = TabCRCLo[Index];
	}
	return (CRCHi << 8 | CRCLo);
}

void InitModBus()
{
	ModBusState.U_State = 1;
	ModBusState.Status.FrameErr = 0;
	ModBusState.Status.isFrame = 0;
	ModBusState.Timer = 0;

}








//----------�������� �������� �������� ������� 0x01, 0x02---------------------
void GetRegister_0x01_0x02(unsigned char * ADU_res2)
{
	if((temp_uchar2%8)==0)	//�������� ����� ����
	{
		if(temp_uchar2/8 >= 1) temp_uint3++; //������ ����� ����
		ADU_res2[temp_uint3] = 0x00;
	}

	//----------TC[1-13]------------------------------------------------------
	if(temp_uint<=0x000D)
	{
		if(TC[temp_uint-1])
		{
			ADU_res2[temp_uint3]|= (0x01<<(temp_uchar2%8));
		}
	}

}

//----------��������� ����� ������� �� ������� 0x01, 0x02---------------------
void FillADU_0x01_x02(unsigned int StopAddress, unsigned char * ADU_res1)
{
	temp_uchar2 = 0;	//������� ������������ Coil ��� DI
	while(temp_uint<=StopAddress)
	{
		GetRegister_0x01_0x02(ADU_res1);
		temp_uint++;						//����� ���������
		temp_uchar2++;
	}

	temp_uint3 += 3;			//��������� ��� ����� CRC16, � ������ ���� � �������, ������� �� ����
	ADU_res1[2] = temp_uint3-5;	//ByteCount
}

//----------�������� �������� �������� ������� 0x03, 0x04---------------------
void GetRegister_0x03_0x04(unsigned char * ADU_res2)
{
	//temp_uint3 - ����� ������ � ������ � ADU_res
	//temp_uint - ����� �������� ������� ����� ��������

	//----------��[1-13] (0x0001-0x000D)--------------------------------------
	if(temp_uint<=0x000D)
	{
		ADU_res2[temp_uint3] = 0;
		ADU_res2[temp_uint3+1] = (TC[temp_uint-1])? 0x01 : 0x00;
	}

	//----------��[1-15] 15*2 =30 �������� (0x0100-0x011D)--------------------
	if(temp_uint>=0x0100 && temp_uint<=0x011D)
	{
		temp_pflt = (unsigned char *) &TI[(temp_uint-0x0100)/2];
		if((temp_uint-0x0100)%2==0)
		{
			ADU_res2[temp_uint3+0] = *(temp_pflt+1);
			ADU_res2[temp_uint3+1] = *(temp_pflt+0);
		}
		else
		{
			ADU_res2[temp_uint3+0] = *(temp_pflt+3);
			ADU_res2[temp_uint3+1] = *(temp_pflt+2);
		}
	}
	//----------Version (0x0400-0x0406)---------------------------------------
	if(temp_uint>=0x0400 && temp_uint<=0x0406)
	{
		ADU_res2[temp_uint3+0] = 0x00;
		if(temp_uint==0x0400) ADU_res2[temp_uint3+1] = SW_VERSION1;
		if(temp_uint==0x0401) ADU_res2[temp_uint3+1] = SW_VERSION2;
		if(temp_uint==0x0402) ADU_res2[temp_uint3+1] = SW_VERSION3;
		if(temp_uint==0x0403) ADU_res2[temp_uint3+1] = SW_VERSION4;
		if(temp_uint==0x0404) ADU_res2[temp_uint3+1] = HW_VERSION1;
		if(temp_uint==0x0405) ADU_res2[temp_uint3+1] = HW_VERSION2;
		if(temp_uint==0x0406) ADU_res2[temp_uint3+1] = DEV_TYPE;
	}
	//----------Time&Date (0x0500-0x0505)-------------------------------------
	if(temp_uint>=0x0500 && temp_uint<=0x0505)
	{
		if(temp_uint==0x0500)
		{
			ADU_res2[temp_uint3+0] = DT_mC>>8;
			ADU_res2[temp_uint3+1] = DT_mC;
		}
		if(temp_uint==0x0501)
		{
			ADU_res2[temp_uint3+0] = 0x00;
			ADU_res2[temp_uint3+1] = DT_Minute;
		}
		if(temp_uint==0x0502)
		{
			ADU_res2[temp_uint3+0] = 0x00;
			ADU_res2[temp_uint3+1] = DT_Hour;
		}
		if(temp_uint==0x0503)
		{
			ADU_res2[temp_uint3+0] = 0x00;
			ADU_res2[temp_uint3+1] = DT_Day;
		}
		if(temp_uint==0x0504)
		{
			ADU_res2[temp_uint3+0] = 0x00;
			ADU_res2[temp_uint3+1] = DT_Month;
		}
		if(temp_uint==0x0505)
		{
			ADU_res2[temp_uint3+0] = 0x00;
			ADU_res2[temp_uint3+1] = DT_Year;
		}
	}
	//----------Stat Info (0x0600-0x06FF)-------------------------------------
	/*
	if(temp_uint>=0x0600 && temp_uint<=0x06FF)
	{
		switch(temp_uint)
		{
			//------------------------ 1 -----------------------
		case 0x0600:
		case 0x0601:
		case 0x0602:
		case 0x0603:
			ADU_res2[temp_uint3+0] = P_TSensor[0]->Id[(temp_uint-0x0600)*2];
			ADU_res2[temp_uint3+1] = P_TSensor[0]->Id[(temp_uint-0x0600)*2+1];
			break;
		case 0x0604:
		case 0x0605:
		case 0x0606:
		case 0x0607:
			ADU_res2[temp_uint3+0] = P_TSensor[1]->Id[(temp_uint-0x0604)*2];
			ADU_res2[temp_uint3+1] = P_TSensor[1]->Id[(temp_uint-0x0604)*2+1];
			break;
		case 0x0608:
		case 0x0609:
		case 0x060A:
		case 0x060B:
			ADU_res2[temp_uint3+0] = P_TSensor[2]->Id[(temp_uint-0x0608)*2];
			ADU_res2[temp_uint3+1] = P_TSensor[2]->Id[(temp_uint-0x0608)*2+1];
			break;
		case 0x060C:
		case 0x060D:
		case 0x060E:
		case 0x060F:
			ADU_res2[temp_uint3+0] = P_TSensor[3]->Id[(temp_uint-0x060C)*2];
			ADU_res2[temp_uint3+1] = P_TSensor[3]->Id[(temp_uint-0x060C)*2+1];
			break;
		case 0x0610:
		case 0x0611:
		case 0x0612:
		case 0x0613:
			ADU_res2[temp_uint3+0] = P_TSensor[4]->Id[(temp_uint-0x0610)*2];
			ADU_res2[temp_uint3+1] = P_TSensor[4]->Id[(temp_uint-0x0610)*2+1];
			break;




		case 0x0620:
		case 0x0621:
		case 0x0622:
		case 0x0623:
		case 0x0624:
			ADU_res2[temp_uint3+0] = P_TSensor[0]->ScrathPad[(temp_uint-0x0620)*2];
			if((temp_uint-0x0620)!=0x04)
				ADU_res2[temp_uint3+1] = P_TSensor[0]->ScrathPad[(temp_uint-0x0620)*2+1];
			else
				ADU_res2[temp_uint3+1] = 0xFF;
		break;
		case 0x0630:
		case 0x0631:
		case 0x0632:
		case 0x0633:
		case 0x0634:
			ADU_res2[temp_uint3+0] = P_TSensor[1]->ScrathPad[(temp_uint-0x0630)*2];
			if((temp_uint-0x0630)!=0x04)
				ADU_res2[temp_uint3+1] = P_TSensor[1]->ScrathPad[(temp_uint-0x0630)*2+1];
			else
				ADU_res2[temp_uint3+1] = 0xFF;
		break;
		case 0x0640:
		case 0x0641:
		case 0x0642:
		case 0x0643:
		case 0x0644:
			ADU_res2[temp_uint3+0] = P_TSensor[2]->ScrathPad[(temp_uint-0x0640)*2];
			if((temp_uint-0x0640)!=0x04)
				ADU_res2[temp_uint3+1] = P_TSensor[2]->ScrathPad[(temp_uint-0x0640)*2+1];
			else
				ADU_res2[temp_uint3+1] = 0xFF;
		break;
		case 0x0650:
		case 0x0651:
		case 0x0652:
		case 0x0653:
		case 0x0654:
			ADU_res2[temp_uint3+0] = P_TSensor[3]->ScrathPad[(temp_uint-0x0650)*2];
			if((temp_uint-0x0650)!=0x04)
				ADU_res2[temp_uint3+1] = P_TSensor[3]->ScrathPad[(temp_uint-0x0650)*2+1];
			else
				ADU_res2[temp_uint3+1] = 0xFF;
		break;
		case 0x0660:
		case 0x0661:
		case 0x0662:
		case 0x0663:
		case 0x0664:
			ADU_res2[temp_uint3+0] = P_TSensor[4]->ScrathPad[(temp_uint-0x0660)*2];
			if((temp_uint-0x0660)!=0x04)
				ADU_res2[temp_uint3+1] = P_TSensor[4]->ScrathPad[(temp_uint-0x0660)*2+1];
			else
				ADU_res2[temp_uint3+1] = 0xFF;
		break;


		default:
			ADU_res2[temp_uint3+0] = 0xFF;
			ADU_res2[temp_uint3+1] = 0xFF;
		break;
		}
	}
	*/

	temp_uint3 += 2;
}




void FillADU_0x03_0x04(unsigned int StopAddress, unsigned char * ADU_res1)
{
	while(temp_uint<=StopAddress)
	{
		GetRegister_0x03_0x04(ADU_res1);
		temp_uint++;
	}
	temp_uint3 += 2;			//��������� ��� ����� CRC16
	ADU_res1[2] = temp_uint3-5;	//ByteCount
}


//----------------------------------------------------------------------------
void WriteRegister_0x06_0x10(unsigned int Address, unsigned int Value)
{
	if(!(Value&0x8000))	//������� ��� ������� undef
	{
		Value &= 0x3FFF;
		if(Address==0x0051)
		{
			if(Value!=0)
				TU_channel.TU_Modbus = 0x0001;
		}
	}
}


void FillADU_0x10(unsigned int StopAddress, unsigned char * ADU_req1,unsigned char * ADU_res1)
{
	temp_uchar2 = 0;
	while(temp_uint<=StopAddress)
	{
		WriteRegister_0x06_0x10(temp_uint, (ADU_req1[7+temp_uchar2*2]<<8)|ADU_req1[8+temp_uchar2*2]);
		temp_uint++;
		temp_uchar2++;	//���-�� ������������
	}
}

//----------��������� ����� ADU ModBus----------------------------------------

unsigned char ProcessADU(unsigned char * ADU_req, unsigned char ADU_Len_req, unsigned char * ADU_res)
{
	//unsigned char len = 0;			- temp_uint3
	//unsigned int data_adr = 0x0000;	- temp_uint
	//unsigned char quantity = 0x00;	- temp_uint2
	//TI_pointer = 0;					- temp_pflt
	//TempDWORD = 0xFFFFFFFF;			- temp_ulongint

	ErrorCode = 0x00;
	//temp_ulongint = 0xFFFFFFFF;		//WORD - ��� ��������� �������
	temp_pflt = 0;					//���������
	temp_uint = 0x0000;				//�����
	temp_uint2 = 0x00;				//���-�� ��������� (quantity)

	ADU_res[0] = ADU_req[0];		//NetAddress
	ADU_res[1] = ADU_req[1];		//func code

	temp_uint = ADU_req[2];			//����� ��������
	temp_uint <<= 8;
	temp_uint |= ADU_req[3];

	temp_uint3 = 3; 				//����� ��������� ������ (������ 3 �.�. ����� ��������� ����
									// ADU_res[2] - ���-�� ���� � ������
	switch (ADU_req[1])		//Check function Code
	{
	case 0x01:			//Read Coils
	case 0x02:			//Read Discrete Inputs
		temp_uint2 = ADU_req[4];	//quantity
		temp_uint2 <<= 8;
		temp_uint2 |= ADU_req[5];
		if(temp_uint2>=0x0001 && temp_uint2<=0x07D0)
		{
				//��������� �������:
				//1) 0x0001-0x000D - ��[13]
			if(temp_uint>=0x0001 && (temp_uint+(temp_uint2-1))<=0x000D)
			{
				FillADU_0x01_x02(temp_uint+(temp_uint2-1), ADU_res);
			}
			else ErrorCode = ILLEGAL_DATA_ADDRESS;	//exception code = 0x02
		}
		else ErrorCode = ILLEGAL_DATA_VALUE; 		//exception code = 0x03
		break;

	case 0x03:			//Read Holding Registers
	case 0x04:			//Read Input Registers
		temp_uint2 = ADU_req[4];	//quantity
		temp_uint2 <<= 8;
		temp_uint2 |= ADU_req[5];
		if (temp_uint2>=0x0001 && temp_uint2<=0x007D)		//Check Quantity
		{

			// ��������� �������:
			//	1)0x0000-0x000D - ��
			//	2)0x0100-0x011D - �� ()
			//	3)0x0500-0x0505 - TimeDate
			//	4)0x0400-0x0406 - Version & DevID
			//	5)0x0600-0x0600 - Statistic
			//

			if( (temp_uint>=0x0001 && (temp_uint+(temp_uint2-1))<=0x000D) ||
				(temp_uint>=0x0100 && (temp_uint+(temp_uint2-1))<=0x011D) ||
				(temp_uint>=0x0400 && (temp_uint+(temp_uint2-1))<=0x0406) ||
				(temp_uint>=0x0500 && (temp_uint+(temp_uint2-1))<=0x0505) /*||
				(temp_uint>=0x0600 && (temp_uint+(temp_uint2-1))<=0x06FF) */)
			{
				FillADU_0x03_0x04(temp_uint+(temp_uint2-1), ADU_res);
			}
			else
			{
				ErrorCode = ILLEGAL_DATA_ADDRESS;
			}
		}
		else
		{
			ErrorCode = ILLEGAL_DATA_VALUE; 		//exception code = 0x03
		}
		break;
	case 0x06:	//Write Single Register
		/* ��������� �������:
		1)0x0051        - ����� ������� OUT
		*/
		if(temp_uint==0x0051)
		{
			ADU_res[2] = ADU_req[2];
			ADU_res[3] = ADU_req[3];
			ADU_res[4] = ADU_req[4];
			ADU_res[5] = ADU_req[5];
			WriteRegister_0x06_0x10(temp_uint, (ADU_req[4]<<8)|ADU_req[5]);
			temp_uint3 = 8;
		}
		else
		{
			ErrorCode = ILLEGAL_DATA_ADDRESS;
		}
		break;
	case 0x10:	//Write Multiple registers
		temp_uint2 = ADU_req[4];	//quantity
		temp_uint2 <<= 8;
		temp_uint2 |= ADU_req[5];
		if (temp_uint2>=0x0001 && temp_uint2<=0x007B &&
			ADU_req[6]==(temp_uint2*2))			//Check Quantity&ByteCount
		{
			/* ��������� �������:
			1)0x0051        - ����� ������� OUT
			*/

			if(temp_uint==0x0051 && temp_uint2==0x01)
			{
				ADU_res[2] = ADU_req[2];
				ADU_res[3] = ADU_req[3];
				ADU_res[4] = ADU_req[4];
				ADU_res[5] = ADU_req[5];
				FillADU_0x10(temp_uint+(temp_uint2-1), ADU_req, ADU_res);
				temp_uint3 = 8;
			}
			else
			{
				ErrorCode = ILLEGAL_DATA_ADDRESS;
			}
		}
		else
		{
			ErrorCode = ILLEGAL_DATA_VALUE; 		//exception code = 0x03
		}
		break;

	case 0x17:	// Read/Write Multiple Registers
		//Tx: 01 17 40 55 00 04 40 AA 00 04 07 55 AA 83 07 00 00 8A 66 BC
		//     0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19

		if( (ADU_req[2]==0x40) && (ADU_req[3]==0x55) && (ADU_req[4]==0x00) && (ADU_req[5]==0x04) &&
			(ADU_req[6]==0x40) && (ADU_req[7]==0xAA) && (ADU_req[8]==0x00) && (ADU_req[9]==0x04) )
		{
			ADU_res[1] = ADU_req[1];	//func code
			ADU_res[2] = ADU_req[10];	//NumByte


			RS232.BufRxCounter = ADU_req[10];
			for(i_main_1=0; i_main_1<ADU_req[10]; i_main_1++) RS232.BufRx[i_main_1] = ADU_req[11+i_main_1];
			AnalyzeRS232Frame();
			RS232.BufRxCounter = 0;


			for(i_main_1=0; i_main_1<ADU_req[10]; i_main_1++)
			{
				ADU_res[3+i_main_1] = RS232.BufTx[i_main_1];
				temp_uint3++;
			}
			temp_uint3 += 2;
		}
		else
		{
			ErrorCode = ILLEGAL_FUNCTION; 	//exception code = 0x01
		}
		break;

	default:
		ErrorCode = ILLEGAL_FUNCTION;		//exception code = 0x01
		break;
	}

	if(ErrorCode)
	{
			ADU_res[1] |= 0x80;
			ADU_res[2] = ErrorCode;
			temp_uint3 = 5;
	}

	return temp_uint3; //����� ������
}

//----------��������� ModBus--------------------------------------------------
void ProcessModBus(void)
{
	if(ModBusState.Status.isFrame)	//�������� ����� �������� ��������
	{
		if (ModBusState.Status.FrameErr==0)						//�������� �� ������
		{
			if (UARTdata.BufRx[0]==UARTdata.NetAddress)	//�������� �� ������ ������
			{
				if(UARTdata.BufRxCounter<=4)						//�������� �� �������� �����
				{
					ModBusState.Status.FrameErr = 1;
#ifdef COUNT_STAT
					SystemData.U_Length_Err[0]++;	//statinfo
#endif
				}
				else
				{
					CRC16 = CalculateCRC16(UARTdata.BufRx, UARTdata.BufRxCounter-2);
					if( (CRC16&0x00FF)!=UARTdata.BufRx[UARTdata.BufRxCounter-2] ||
						((CRC16&0xFF00)>>8)!=UARTdata.BufRx[UARTdata.BufRxCounter-1] )
					{
						ModBusState.Status.FrameErr = 1;
#ifdef COUNT_STAT
						SystemData.U_CRC_Err[0]++;	//statinfo
#endif
					}
				}
			}
			else
			{
				ModBusState.Status.FrameErr = 1;	//����� ������ �� ���
#ifdef COUNT_STAT
				SystemData.U_Address_Err[0]++;		//statinfo
#endif
			}

			//---------- ������������ ���������� ����� -----------------------
			if(ModBusState.Status.FrameErr==0)
			{
#ifdef COUNT_STAT
				SystemData.U_RcvFrame_OK[0]++;	//statinfo
#endif
				UARTdata.BufTxMessLen = ProcessADU(UARTdata.BufRx, UARTdata.BufRxCounter, UARTdata.BufTx);
				if(UARTdata.BufTxMessLen>1)
				{
					CRC16 = CalculateCRC16(UARTdata.BufTx, UARTdata.BufTxMessLen-2);
					UARTdata.BufTx[UARTdata.BufTxMessLen-2] = CRC16&0x00FF;			//Low
					UARTdata.BufTx[UARTdata.BufTxMessLen-1] = (CRC16&0xFF00)>>8;		//High

					//����� ����� ���������
					ModBusState.U_State = 6;
					UARTdata.Status.START_TX = 1;
					UARTdata.Timer = 0;

				}
				else	//�� ProcessADU ������ ����� ������ 2-� ����
				{
					ModBusState.U_State = 2;
				}
			}
			else
			{
				ModBusState.U_State = 2;
			}
			//---------- ������������ ���������� ����� -----------------------
		}
		else		//���� ������ ��� ��������� (������������)
		{
			ModBusState.U_State = 2;
#ifdef COUNT_STAT
			SystemData.U_Buffer_Err[0]++;	//statinfo
#endif
		}
		UARTdata.BufRxCounter = 0;
		ModBusState.Status.FrameErr = 0;
		ModBusState.Status.isFrame = 0;
	}
}


